using IRISElementsBookkeeping.Constants;

namespace IRISElementsBookkeeping.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void Database_DB_NAME_ShouldBeCorrect()
        {
            // Arrange
            const string expected = "MyApplication";

            // Act
            var actual = StringConstants.General.APP_NAME;

            // Assert
            Assert.Equal(expected, actual);
        }
    }
}