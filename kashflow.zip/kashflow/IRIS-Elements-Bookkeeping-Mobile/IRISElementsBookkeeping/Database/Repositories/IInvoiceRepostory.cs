﻿namespace IRISElementsBookkeeping.Database.Repositories
{
    public interface IInvoiceRepostory : IRepositoryBase<Invoice>
    {
        Task<int> AddInvoice(Invoice invoice);
        Task<List<Invoice>> GetInvoice();
    }
}
