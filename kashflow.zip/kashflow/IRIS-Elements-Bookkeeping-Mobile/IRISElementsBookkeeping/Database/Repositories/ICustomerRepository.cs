﻿namespace IRISElementsBookkeeping.Database.Repositories
{
    public interface ICustomerRepository
    {
    }
}
