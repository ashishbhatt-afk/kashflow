﻿namespace IRISElementsBookkeeping.Database.Repositories
{
    public class CustomerRepository : RepositoryBase<Customer>, ICustomerRepository
    {
        public CustomerRepository(IDBContext dbContext) : base(dbContext)
        {

        }
    }
}
