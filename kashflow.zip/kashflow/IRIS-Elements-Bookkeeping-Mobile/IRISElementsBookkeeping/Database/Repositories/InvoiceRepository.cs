﻿namespace IRISElementsBookkeeping.Database.Repositories
{
    public class InvoiceRepository : RepositoryBase<Invoice>, IInvoiceRepostory
    {
        public InvoiceRepository(IDBContext dbContext) : base(dbContext)
        {

        }
        public async Task<int> AddInvoice(Invoice invoice)
        {
            return await InsertAsync(invoice);
        }

        public async Task<List<Invoice>> GetInvoice()
        {
            return await GetAllAsync();
        }
    }
}
