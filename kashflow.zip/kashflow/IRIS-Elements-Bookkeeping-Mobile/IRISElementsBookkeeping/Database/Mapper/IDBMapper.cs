﻿namespace IRISElementsBookkeeping.Database.Mapper
{
    public interface IDBMapper<TEntity, TDto>
    {
        TDto MapToDTO(TEntity entity);
        TEntity MapToEnity(TDto dto);
        
    }
}
