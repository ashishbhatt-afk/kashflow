﻿using Riok.Mapperly.Abstractions;

namespace IRISElementsBookkeeping.Database.Mapper
{
    [Mapper]
    public partial class InvoiceDBMapper : IDBMapper<Invoice, InvoiceDTO>
    {
        public partial InvoiceDTO MapToDTO(Invoice invoice);

        public partial Invoice MapToEnity(InvoiceDTO invoiceDTO);
        
    }


    [Mapper]
    public partial class CustomerDBMapper : IDBMapper<Customer, CustomerDTO>
    {
        public partial CustomerDTO MapToDTO(Customer invoice);

        public partial Customer MapToEnity(CustomerDTO invoiceDTO);
        
    }
}
