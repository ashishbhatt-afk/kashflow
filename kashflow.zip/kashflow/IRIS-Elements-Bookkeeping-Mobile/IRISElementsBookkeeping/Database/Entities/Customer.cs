﻿using SQLite;

namespace IRISElementsBookkeeping.Database.Entities
{
    [Table("customer")]
    public class Customer
    {
        [PrimaryKey, Column("customer_id")]
        public string CustomerID { get; set; } = string.Empty;

        [Column("name")]
        public string Name { get; set; } = string.Empty;

        [Column("email")]
        public string Email { get; set; } = string.Empty;
    }
}
