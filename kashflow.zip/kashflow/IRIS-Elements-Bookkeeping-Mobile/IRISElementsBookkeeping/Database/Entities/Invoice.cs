﻿using SQLite;

namespace IRISElementsBookkeeping.Database.Entities
{
    [Table("invoice")]
    public class Invoice
    {
        [PrimaryKey, AutoIncrement, Column("invoice_id")]
        public int InvoiceId { get; set; }

        [Column("invoice_date")]
        public string InvoiceDate { get; set; } = string.Empty;

        [Column("description")]
        public string Description { get; set; } = string.Empty;

        [Column("rate")]
        public string Rate { get; set; } = "100";
    }
}
