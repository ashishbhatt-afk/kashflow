﻿using SQLite;

namespace IRISElementsBookkeeping.Database
{
    public class DBContext : IDBContext
    {
        public SQLiteAsyncConnection Connection { get; }

        public DBContext(string dbpath)
        {
            Connection = new SQLiteAsyncConnection(dbpath,
                SQLiteOpenFlags.Create | SQLiteOpenFlags.ReadWrite | SQLiteOpenFlags.SharedCache);
        }

        public async Task CreateAllTableAsync()
        {
            await Connection.CreateTableAsync<Invoice>();
        }

        public async Task DeleteAllDataAsync()
        {
            await Connection.DeleteAllAsync<Invoice>();
        }
    }
}
