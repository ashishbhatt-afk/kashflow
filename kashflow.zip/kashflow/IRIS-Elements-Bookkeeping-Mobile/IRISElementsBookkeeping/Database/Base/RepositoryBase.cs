﻿using System.Linq.Expressions;

namespace IRISElementsBookkeeping.Database.Base
{
    public abstract class RepositoryBase<T> : IRepositoryBase<T> where T : new()
    {
        private readonly IDBContext dbContext;

        public RepositoryBase(IDBContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<List<T>> GetAllAsync()
        {
            return await dbContext.Connection.Table<T>().ToListAsync();
        }

        public async Task<List<T>> FindByCondition(Expression<Func<T, bool>> expression)
        {
            return await dbContext.Connection.Table<T>().ToListAsync();
        }

        public async Task<int> UpdateAsync(T entity)
        {
            return await dbContext.Connection.UpdateAsync(entity);
        }

        public async Task<int> UpdateAllAsync(List<T> entity)
        {
            return await dbContext.Connection.UpdateAllAsync(entity);
        }

        public async Task<int> InsertAsync(T entity)
        {
            return await dbContext.Connection.InsertAsync(entity);
        }

        public async Task<int> InsertAllAsync(List<T> entity)
        {
            return await dbContext.Connection.InsertAllAsync(entity);
        }
    }
}
