﻿using System.Linq.Expressions;

namespace IRISElementsBookkeeping.Database.Base
{
    public interface IRepositoryBase<T>
    {
        Task<List<T>> GetAllAsync();
        Task<List<T>> FindByCondition(Expression<Func<T, bool>> expression);
        Task<int> InsertAsync(T entity);
        Task<int> InsertAllAsync(List<T> entity);
        Task<int> UpdateAsync(T entity);
        Task<int> UpdateAllAsync(List<T> entity);
    }


}
