﻿namespace IRISElementsBookkeeping.Database.Wrapper
{
    public interface IRepositoryWrapper
    {
        IInvoiceRepostory InvoiceRepo { get; }
        ICustomerRepository CustomerRepo { get; }
    }
}
