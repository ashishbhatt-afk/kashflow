﻿namespace IRISElementsBookkeeping.Database.Wrapper
{
    public class RepositoryWrapper : IRepositoryWrapper
    {
        private IInvoiceRepostory? invoiceRepostory;
        private ICustomerRepository? customerRepository;
        private readonly IRepositoryFactory repositoryFactory;

        public RepositoryWrapper(IRepositoryFactory repositoryFactory)
        {
            this.repositoryFactory = repositoryFactory;
        }

        public IInvoiceRepostory InvoiceRepo
        {
            get
            {
                if (invoiceRepostory == null)
                {
                    invoiceRepostory = repositoryFactory.GetRepository<IInvoiceRepostory>();
                }
                return invoiceRepostory;
            }
        }

        public ICustomerRepository CustomerRepo
        {
            get
            {
                if (customerRepository == null)
                {
                    customerRepository = repositoryFactory.GetRepository<ICustomerRepository>();
                }
                return customerRepository;
            }
        }
    }
}
