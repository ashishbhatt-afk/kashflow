﻿namespace IRISElementsBookkeeping.Database.Factory
{
    public interface IRepositoryFactory
    {
        T GetRepository<T>() where T : class;
    }
}
