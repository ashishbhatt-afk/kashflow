﻿using SQLite;

namespace IRISElementsBookkeeping.Database
{
    public interface IDBContext

    {
        SQLiteAsyncConnection Connection { get; }

        Task CreateAllTableAsync();

        Task DeleteAllDataAsync();

    }

}
