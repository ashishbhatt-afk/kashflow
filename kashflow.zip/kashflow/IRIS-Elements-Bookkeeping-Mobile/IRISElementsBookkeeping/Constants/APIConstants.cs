﻿namespace IRISElementsBookkeeping.Constants
{
    public static class APIConstants
    {
        //Example
        public const string BASEURL_DEV = "https://catfact.ninja/fact";
    }
}
