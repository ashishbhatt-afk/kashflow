﻿namespace IRISElementsBookkeeping.Constants
{
    public static class StringConstants
    {
        public static class Database
        {
            public const string DB_NAME = "Bookkeeping.db3";
        }

        public static class General
        {
            public const string APPCENTER_ANDROID = "67f800af-9855-4d08-b1d7-a005f729223d";
            public const string APPCENTER_IOS = "f4c9c6d8-0e6c-441e-841b-1a4e5310215e";

            //Examples
            public const string APP_NAME = "MyApplication";
            public const int MAX_USERS = 100;
        }

        public static class Errors
        {
            //Examples
            public const string USER_NOT_FOUND = "User not found.";
            public const string INVALID_INPUT = "Invalid input.";
        }

        public static class ConfigKeys
        {
            //Examples
            public const string DB_CONNECTION_STRING = "DB_CONNECTION_STRING";
        }

    }
}
