﻿using IRISElementsBookkeeping.Services.Navigation;
using IRISElementsBookkeeping.ViewModels.Base;
using Microsoft.AppCenter.Crashes;

namespace IRISElementsBookkeeping.ViewModels
{
    public partial class MainViewModel : ViewModelBase
    {
        private readonly IInvoiceService _invoiceService;
        public MainViewModel(INavigationService navigationService, IInvoiceService invoiceService)
            : base(navigationService)
        {
            _invoiceService = invoiceService;
            TestData();
        }

        private void TestData()
        {
            _invoiceService.SaveInvoice();
            _invoiceService.GetInvoices();
            TestCrash();
        }

        private void TestCrash()
        {
          //  Crashes.GenerateTestCrash();
        }

      
    }
}
