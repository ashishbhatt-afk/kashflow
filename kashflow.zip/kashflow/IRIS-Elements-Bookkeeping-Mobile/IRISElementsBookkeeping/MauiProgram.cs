﻿using Microsoft.Extensions.Logging;
using CommunityToolkit.Maui;
using IRISElementsBookkeeping.Extensions;
using IRISElementsBookkeeping.Services.RequestProvider;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;
using Microsoft.AppCenter;

namespace IRISElementsBookkeeping
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .UseMauiCommunityToolkit()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                });
            builder.Services.AddHttpClient<IRequestProvider, RequestProvider>(httpClient =>
            {
                httpClient.BaseAddress = new Uri(APIConstants.BASEURL_DEV);
                httpClient.DefaultRequestHeaders.Add("Accept", "application/json");
                httpClient.Timeout = TimeSpan.FromSeconds(30); // Example timeout setting
            });

            //Database
            builder.Services.RegisterDBContext();

            //App Services
            builder.Services.RegisterAppServices();

            //Other Services
            builder.Services.RegisterOtherServices();

            //Repositories
            builder.Services.RegisterRepositories();

            //Mappers
            builder.Services.RegisterMappers();

            //ViewModels
            builder.Services.RegisterViewModels();

            //Views
            builder.Services.RegisterViews();

#if DEBUG
    		builder.Logging.AddDebug();
#endif
            var mauiApp = builder.Build();

            // Initialize the database
            InitializeDatabase(mauiApp.Services);

            // Initialize App Center
            AppCenter.Start($"ios={StringConstants.General.APPCENTER_IOS};android={StringConstants.General.APPCENTER_ANDROID};",
            typeof(Analytics), typeof(Crashes));


            return mauiApp;
        }
        private static async void InitializeDatabase(IServiceProvider serviceProvider)
        {
            // Get the database context
            var dbContext = serviceProvider.GetRequiredService<IDBContext>();

            // Create tables
            await dbContext.CreateAllTableAsync();
        }
    }
}
