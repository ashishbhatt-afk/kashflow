﻿using IRISElementsBookkeeping.Services.Mapper;
using IRISElementsBookkeeping.Services.Navigation;
using IRISElementsBookkeeping.Services.RequestProvider;
using IRISElementsBookkeeping.ViewModels;
using IRISElementsBookkeeping.Views;

namespace IRISElementsBookkeeping.Extensions
{
    public static class ServiceExtensions
    {

        public static void RegisterDBContext(this IServiceCollection services)
        {
            services.AddSingleton<IDBContext>(p => new DBContext(Path.Combine(FileSystem.Current.AppDataDirectory, StringConstants.Database.DB_NAME)));   
        }

        public static void RegisterRepositories(this IServiceCollection services)
        {
            // Resitration of RepositoryWrapper
            services.AddScoped<IRepositoryWrapper, RepositoryWrapper>();

            //Registration of RepositoryFactory
            services.AddScoped<IRepositoryFactory, RepositoryFactory>();

            //Registration Repositories
            services.AddScoped<IInvoiceRepostory, InvoiceRepository>();
            services.AddScoped<ICustomerRepository, CustomerRepository>();
            
        }
        public static void RegisterAppServices(this IServiceCollection services)
        {
           services.AddSingleton<INavigationService, MauiNavigationService>();
           services.AddSingleton<IRequestProvider, RequestProvider>();
        }

        public static void RegisterMappers(this IServiceCollection services)
        {
            services.AddSingleton<IDBMapper<Invoice, InvoiceDTO>, InvoiceDBMapper>();
            services.AddSingleton<IWebMapper<InvoiceResponse, InvoiceResponseDto>, InvoiceWebMapper>();
        }

            public static void RegisterOtherServices(this IServiceCollection services)
        {
            services.AddSingleton<IInvoiceService, InvoiceService>();
        }

        public static void RegisterViewModels(this IServiceCollection services)
        {
            services.AddTransient<MainViewModel>();
        }
        public static void RegisterViews(this IServiceCollection services)
        {
            services.AddTransient<MainPage>();
        }
    }
}
