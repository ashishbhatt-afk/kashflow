﻿using System.Net;

namespace IRISElementsBookkeeping.Exceptions
{
    public class HttpRequestExceptionEx : Exception
    {
        public HttpStatusCode StatusCode { get; }

        public HttpRequestExceptionEx(HttpStatusCode statusCode)
            : base($"Request failed with status code {statusCode}")
        {
            StatusCode = statusCode;
        }

        public HttpRequestExceptionEx(HttpStatusCode statusCode, string message)
            : base(message)
        {
            StatusCode = statusCode;
        }

        public HttpRequestExceptionEx(HttpStatusCode statusCode, string message, Exception inner)
            : base(message, inner)
        {
            StatusCode = statusCode;
        }
    }
}
