﻿using IRISElementsBookkeeping.Services.Mapper;
using IRISElementsBookkeeping.Services.RequestProvider;

namespace IRISElementsBookkeeping.Services.Invoices
{
    public class InvoiceService : IInvoiceService
    {
        private readonly IDBMapper<Invoice, InvoiceDTO> _invoiceDBMapper;
        private readonly IWebMapper<InvoiceResponse, InvoiceResponseDto> _invoiceWebMapper;
        private readonly IRequestProvider _requestProvider;
        private readonly IRepositoryWrapper _repositoryWrapper;

        public InvoiceService(IRequestProvider requestProvider, IRepositoryWrapper repositoryWrapper, 
                              IDBMapper<Invoice, InvoiceDTO> invoiceDBMapper, IWebMapper<InvoiceResponse, 
                              InvoiceResponseDto> invoiceWebMapper)
        {
            _requestProvider = requestProvider;
            _repositoryWrapper = repositoryWrapper;
            _invoiceDBMapper = invoiceDBMapper;
            _invoiceWebMapper = invoiceWebMapper;
        }

        public async void SaveInvoice()
        {
            InvoiceDTO invoiceDto = new InvoiceDTO() { InvoiceDate = "17-07-2014", Description = "XYZ" };
            var data = _invoiceDBMapper.MapToEnity(invoiceDto);
            var result = await _repositoryWrapper.InvoiceRepo.AddInvoice(data);
            var list = await _repositoryWrapper.InvoiceRepo.GetInvoice();
        }

        public async Task<InvoiceResponse?> GetInvoices()
        {
            var response = await _requestProvider.GetAsync<InvoiceResponseDto>(APIConstants.BASEURL_DEV);
            if (response?.Data != null && response.Success)
            {
                return _invoiceWebMapper.MapToWebModel(response.Data);
            }
            else
            {
                return null;
            }
        }
    }
}
