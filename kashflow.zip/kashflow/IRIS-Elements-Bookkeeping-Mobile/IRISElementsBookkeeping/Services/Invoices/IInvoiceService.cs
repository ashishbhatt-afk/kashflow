﻿namespace IRISElementsBookkeeping.Services.Invoices
{
    public interface IInvoiceService
    {
        Task<InvoiceResponse?> GetInvoices();
        void SaveInvoice();
    }
}
