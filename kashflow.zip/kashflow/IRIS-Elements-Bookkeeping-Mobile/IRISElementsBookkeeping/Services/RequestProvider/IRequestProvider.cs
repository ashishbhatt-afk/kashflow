﻿namespace IRISElementsBookkeeping.Services.RequestProvider
{
    public interface IRequestProvider
    {
        Task<Response<T>> GetAsync<T>(string endpoint, Dictionary<string, string>? headers = null);
        Task<Response<T>> PostAsync<T>(string endpoint, object data, Dictionary<string, string>? headers = null, string? contentType = null);
        Task<Response<T>> PutAsync<T>(string endpoint, object data, Dictionary<string, string>? headers = null, string? contentType = null);
        Task<Response<bool>> DeleteAsync(string endpoint, Dictionary<string, string>? headers = null);
    }
}
