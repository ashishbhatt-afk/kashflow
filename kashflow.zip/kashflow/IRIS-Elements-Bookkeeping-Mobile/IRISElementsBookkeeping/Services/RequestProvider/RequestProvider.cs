﻿using IRISElementsBookkeeping.Exceptions;
using System.Text;
using System.Text.Json;

namespace IRISElementsBookkeeping.Services.RequestProvider
{
    public class RequestProvider : IRequestProvider
    {
        private readonly HttpClient _httpClient;

        public RequestProvider(HttpClient? httpClient)
        {
            _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        }

        private void AddHeaders(HttpRequestMessage request, Dictionary<string, string>? headers)
        {
            // Add additional headers
            if (headers != null)
            {
                foreach (var header in headers)
                {
                    request.Headers.TryAddWithoutValidation(header.Key, header.Value);
                }
            }
        }

        public async Task<Response<T>> GetAsync<T>(string endpoint, Dictionary<string, string>? headers = null)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, endpoint);
                AddHeaders(request, headers);
                var response = await _httpClient.SendAsync(request);
                await HandleHttpResponse(response);
                var json = await response.Content.ReadAsStringAsync();
                return new Response<T>(true, "Success", JsonSerializer.Deserialize<T>(json));
            }
            catch (Exception ex)
            {
                HandleException(ex);
                return new Response<T>(false, ex.Message);
            }

        }

       
        public async Task<Response<T>> PostAsync<T>(string endpoint, object data, Dictionary<string, string>? headers = null, string? contentType = "application/json")
        {
            try
            {
                var content = CreateHttpContent(data, contentType);
                var request = new HttpRequestMessage(HttpMethod.Post, endpoint) { Content = content };
                AddHeaders(request, headers);
                var response = await _httpClient.SendAsync(request);
                await HandleHttpResponse(response);
                var responseJson = await response.Content.ReadAsStringAsync();
                return new Response<T>(true, "Success", JsonSerializer.Deserialize<T>(responseJson));
            }
            catch (Exception ex)
            {
                HandleException(ex);
                return new Response<T>(false, ex.Message);
            }
        }


        public async Task<Response<T>> PutAsync<T>(string endpoint, object data, Dictionary<string, string>? headers = null, string? contentType = "application/json")
        {
            try
            {
                var content = CreateHttpContent(data, contentType);
                var request = new HttpRequestMessage(HttpMethod.Put, endpoint) { Content = content };
                AddHeaders(request, headers);
                var response = await _httpClient.SendAsync(request);
                await HandleHttpResponse(response);
                var responseJson = await response.Content.ReadAsStringAsync();
                return new Response<T>(true, "Success", JsonSerializer.Deserialize<T>(responseJson));
            }
            catch (Exception ex)
            {

                HandleException(ex);
                return new Response<T>(false, ex.Message);
            }
        }

        public async Task<Response<bool>> DeleteAsync(string endpoint, Dictionary<string, string>? headers = null)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Delete, endpoint);
                AddHeaders(request, headers);
                var response = await _httpClient.SendAsync(request);
                await HandleHttpResponse(response);
                var json = await response.Content.ReadAsStringAsync();
                return new Response<bool>(true, "Success", JsonSerializer.Deserialize<bool>(json));
            }
            catch (Exception ex)
            {

                HandleException(ex);
                return new Response<bool>(false, ex.Message);
            }
        }

        private void HandleException(Exception ex)
        {
            Console.WriteLine($"Exception: {ex.Message}");
        }
        private async Task HandleHttpResponse(HttpResponseMessage response)
        {
            if (!response.IsSuccessStatusCode)
            {
                var errorMessage = await response.Content.ReadAsStringAsync();
                throw new HttpRequestExceptionEx(response.StatusCode, errorMessage);
            }
        }

        private HttpContent CreateHttpContent(object data, string? contentType)
        {
            if (data != null)
            {
                if (!String.IsNullOrWhiteSpace(contentType) && contentType == "application/json")
                {
                    var json = JsonSerializer.Serialize(data);
                    return new StringContent(json, Encoding.UTF8, contentType);
                }
                else if (!String.IsNullOrWhiteSpace(contentType) && contentType == "application/x-www-form-urlencoded")
                {
                    var keyValueContent = data as IEnumerable<KeyValuePair<string, string>> ?? throw new ArgumentNullException(nameof(data), "Invalid data parameters");
                    return new FormUrlEncodedContent(keyValueContent);
                }
                else if (!String.IsNullOrWhiteSpace(contentType) && contentType == "multipart/form-data")
                {
                    var multiPartContent = new MultipartFormDataContent();
                    var keyValueContent = data as IEnumerable<KeyValuePair<string, string>> ?? throw new ArgumentNullException(nameof(data), "Invalid data parameters");
                    foreach (var kvp in keyValueContent)
                    {
                        multiPartContent.Add(new StringContent(kvp.Value), kvp.Key);
                    }
                    return multiPartContent;
                }
            }
            throw new ArgumentException("Unsupported content type");
        }
    }
    }
