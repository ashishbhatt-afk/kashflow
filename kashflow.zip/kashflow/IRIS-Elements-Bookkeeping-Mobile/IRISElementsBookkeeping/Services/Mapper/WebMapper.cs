﻿using Riok.Mapperly.Abstractions;

namespace IRISElementsBookkeeping.Services.Mapper
{
    [Mapper]
    public partial class InvoiceWebMapper : IWebMapper<InvoiceResponse, InvoiceResponseDto>
    {
        public partial InvoiceResponseDto MapToDTO(InvoiceResponse invoiceResponse);

        public partial InvoiceResponse MapToWebModel(InvoiceResponseDto invoiceDTO);

    }
}
