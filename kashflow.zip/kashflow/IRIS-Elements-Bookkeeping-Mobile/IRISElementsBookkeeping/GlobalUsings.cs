﻿global using IRISElementsBookkeeping.Database.Entities;
global using IRISElementsBookkeeping.Models.UIModels;

global using CommunityToolkit.Mvvm.ComponentModel;
global using CommunityToolkit.Mvvm.Input;

global using IRISElementsBookkeeping.Database.Mapper;
global using IRISElementsBookkeeping.Models.WebModels;

global using IRISElementsBookkeeping.Database.Repositories;
global using IRISElementsBookkeeping.Database.Wrapper;
global using IRISElementsBookkeeping.Database;
global using IRISElementsBookkeeping.Constants;
global using IRISElementsBookkeeping.Database.Factory;
global using IRISElementsBookkeeping.Services.Invoices;
global using IRISElementsBookkeeping.Database.Base;