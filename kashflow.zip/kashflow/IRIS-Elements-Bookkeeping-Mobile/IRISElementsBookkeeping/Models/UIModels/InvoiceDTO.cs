﻿namespace IRISElementsBookkeeping.Models.UIModels
{
    public record InvoiceDTO
    {
        public string? InvoiceDate { get; set; }
        public string? Description { get; set; }
    }
}
