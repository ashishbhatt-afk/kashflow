﻿namespace IRISElementsBookkeeping.Models.WebModels
{
    public class InvoiceResponse
    {
        public string Fact { get; set; } = string.Empty;
    }
}
