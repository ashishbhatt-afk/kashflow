﻿using System.Text.Json.Serialization;

namespace IRISElementsBookkeeping.Models.WebModels
{
    public record InvoiceResponseDto
    {
        [JsonPropertyName("fact")]
        public string Fact { get; set; } = string.Empty;

        [JsonPropertyName("length")]
        public int Length { get; set; }
    }
}
