﻿namespace IRISElementsBookkeeping.Models.WebModels
{
    public class Response<T>
    {
        public bool Success { get; private set; }
        public string? Message { get; private set; }
        public T? Data { get; private set; }

        public Response(bool success)
        {
            Success = success;
        }

        public Response(bool success, T? data)
        {
            Success = success;
            Data = data;
        }

        public Response(bool success, string? message)
        {
            Success = success;
            Message = message;
        }

        public Response(bool success, string? message, T? data)
        {
            Success = success;
            Message = message;
            Data = data;
        }
    }

}
